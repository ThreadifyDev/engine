"""Run this compiled agent with ``python <artifact> serve|run``."""

from pathlib import Path

import sys

from harnest.runtime import main

raise SystemExit(
    main(["--artifact", str(Path(__file__).parent), *sys.argv[1:]])
)
