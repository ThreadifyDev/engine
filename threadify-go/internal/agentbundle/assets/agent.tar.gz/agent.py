"""Generated Harnest application entrypoint; do not edit."""

from pathlib import Path

from harnest.bundle import compile_application

from harnest.agent_plugin_runtime import plugin_installation

with plugin_installation('17249efdd5052f61c6eb04dd0dc3549f2830c61739c5a21869c8a36ee6459226'):
    application = compile_application(
        Path(__file__).parent / "source",
        entrypoint='agent:root_agent',
        framework='adk',
        mode='managed',
    )
app = application.native_app or application.target
root_agent = application.target
